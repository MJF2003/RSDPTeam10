import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
import tf2_ros
from tf2_geometry_msgs import do_transform_pose
import tf2_py

class NavigationServiceNode(Node):
    def __init__(self):
        super().__init__('navigation_service_node')
        
        # 1. Initialize Nav2 controller
        # 1. 初始化 Nav2 控制器 
        self.navigator = BasicNavigator()
        
        # 2. Initialize TF2 listener for handling camera-to-map transformations
        # 2. 初始化 TF2 监听器，用于处理相机到地图的转换 
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        # 3. Subscribe to the goal coordinates topic
        # 3. 订阅目标坐标话题
        self.subscription = self.create_subscription(
            PoseStamped,
            '/platform_poses',
            self.goal_callback,
            10)
        
        self.get_logger().info('Navigation service node started, supporting real-time coordinate transformation, waiting for goals...')

    def goal_callback(self, msg):
        """
        Process received goal coordinates and transform them from source frame (e.g., camera) to map frame
        处理收到的目标坐标，将其从源坐标系（如相机）转换到地图坐标系（map） 
        """
        source_frame = msg.header.frame_id
        target_frame = 'map'
        
        self.get_logger().info(f'Received coordinates, source frame: {source_frame}')

        try:
            # A. Wait for and retrieve the latest coordinate transformation
            # A. 等待并获取最新的坐标变换关系 
            # lookup_transform automatically finds the transform chain: source_frame -> ... -> base_link -> odom -> map
            # lookup_transform 会自动查找变换链：source_frame -> ... -> base_link -> odom -> map
            now = rclpy.time.Time()
            transform = self.tf_buffer.lookup_transform(
                target_frame,
                source_frame,
                now,
                timeout=rclpy.duration.Duration(seconds=1.0))
            
            # B. Execute coordinate transformation
            # B. 执行坐标转换 
            map_pose = do_transform_pose(msg.pose, transform)

            # C. Construct the final goal point to be sent to Nav2
            # C. 构建发送给 Nav2 的最终目标点 
            nav_goal = PoseStamped()
            nav_goal.header.frame_id = target_frame
            nav_goal.header.stamp = self.get_clock().now().to_msg()
            nav_goal.pose = map_pose

            self.get_logger().info(f'Transformation successful: x={msg.pose.position.x:.2f} -> map_x={map_pose.position.x:.2f}')

            # D. Send navigation command
            # D. 发送导航指令 
            self.navigator.goToPose(nav_goal)

            # E. Loop to monitor progress
            # E. 循环监控进度 
            while not self.navigator.isTaskComplete():
                feedback = self.navigator.getFeedback()
                if feedback:
                    self.get_logger().info(f'Distance remaining: {feedback.distance_remaining:.2f} meters', throttle_duration_sec=1.0)
                
                rclpy.spin_once(self, timeout_sec=0.5)

            # F. Check final result
            # F. 检查最终结果 
            result = self.navigator.getResult()
            if result == TaskResult.SUCCEEDED:
                self.get_logger().info('Successfully arrived at the goal area!')
            elif result == TaskResult.CANCELED:
                self.get_logger().warn('Navigation task was canceled')
            elif result == TaskResult.FAILED:
                self.get_logger().error('Navigation failed')

        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            self.get_logger().error(f'Unable to complete coordinate transformation: {str(e)}')
            self.get_logger().warn('Please confirm if SLAM is running (check for map frame) and if camera TF is being published')

def main(args=None):
    rclpy.init(args=args)
    node = NavigationServiceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()